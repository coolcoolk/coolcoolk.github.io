#!/usr/bin/env bash
# encode_hero_video.sh — Base All hero background video encoder (T-121)
#
# Converts one or two source videos (HDR HLG/10-bit included) into the
# PC and mobile files the base-all console accepts, then checks each
# output against the console's upload rules and reports pass/warn/reject.
#
# This script NEVER modifies the source file(s) it is given. It only reads
# them and writes new files into the output directory.
#
# Usage:
#   encode_hero_video.sh --pc SOURCE_PC.mp4 --mobile SOURCE_MOBILE.mp4 --out OUT_DIR
#   encode_hero_video.sh --source SOURCE.mp4 --out OUT_DIR      # one source -> both outputs
#
# Exit code: 0 only if BOTH outputs pass every reject-class rule (warnings
# do not fail the run, matching the console's own warn-vs-reject contract).

set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------- console upload rules (docs/design.md ## 12 / docs/prd/PRD.md #### 히어로 영상) ----------
MAX_BYTES=$((20 * 1024 * 1024))       # 20 MB reject
MAX_DURATION=30                        # seconds, mp4 reject
PC_W=1920; PC_H=1080                   # recommended, warns only if different
MOBILE_W=720; MOBILE_H=1280
PC_WARN_BPS=5000000                    # >5 Mbps average -> warn
MOBILE_WARN_BPS=3000000                # >3 Mbps average -> warn

# ---------- T-112 captain-chosen delivery settings (also this skill's defaults) ----------
PC_VBITRATE=3500k;  PC_MAXRATE=5250k;  PC_BUFSIZE=7000k
MOBILE_VBITRATE=1900k; MOBILE_MAXRATE=2850k; MOBILE_BUFSIZE=3800k
TONEMAP_NPL=100                        # zscale nominal peak luminance for the HLG->SDR tonemap
LIMITER_LIMIT=0.6310                   # -4 dBFS in linear amplitude (10^(-4/20))
LIMITER_ATTACK=1                       # ms; ffmpeg's 5ms default attack does not catch this
LIMITER_RELEASE=50                     # content's transients (measured -> see SKILL.md "오디오 리미터")
AAC_BITRATE=128k

usage() {
  cat <<'EOF'
Usage:
  encode_hero_video.sh --source SOURCE.mp4 --out OUT_DIR
  encode_hero_video.sh --pc SOURCE_PC.mp4 --mobile SOURCE_MOBILE.mp4 --out OUT_DIR

One source file is encoded into both the PC (1920x1080) and mobile
(720x1280) deliverable. Two source files are encoded one-to-one.
Never edits or moves the source file(s).
EOF
}

log() { printf '%s\n' "$*" >&2; }
die() { log "오류: $*"; exit 1; }

# ---------- 1. find an ffmpeg build that has the zscale filter (needed for HDR tone mapping) ----------
find_capable_ffmpeg() {
  local candidates=()
  command -v ffmpeg >/dev/null 2>&1 && candidates+=("$(command -v ffmpeg)")
  command -v ffmpeg-full >/dev/null 2>&1 && candidates+=("$(command -v ffmpeg-full)")
  if command -v brew >/dev/null 2>&1; then
    local prefix
    prefix="$(brew --prefix ffmpeg-full 2>/dev/null || true)"
    [ -n "$prefix" ] && [ -x "$prefix/bin/ffmpeg" ] && candidates+=("$prefix/bin/ffmpeg")
  fi
  candidates+=("/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg" "/usr/local/opt/ffmpeg-full/bin/ffmpeg")

  local c
  for c in "${candidates[@]}"; do
    [ -x "$c" ] || continue
    if "$c" -filters 2>/dev/null | grep -q "zscale"; then
      echo "$c"
      return 0
    fi
  done
  return 1
}

print_zscale_install_help() {
  cat <<'EOF'
이 컴퓨터의 ffmpeg에는 HDR(HLG/PQ) 영상을 SDR로 톤 매핑하는 데 필요한
zscale 필터가 없습니다(libzimg 없이 빌드됨). 아래 중 이 컴퓨터의 운영체제에
맞는 방법으로 zscale이 포함된 ffmpeg를 설치한 뒤 다시 실행하세요.

- macOS (Homebrew 사용 중이면): `brew install ffmpeg-full`
  설치 후 확인: `$(brew --prefix ffmpeg-full)/bin/ffmpeg -filters | grep zscale`
  (이 스킬은 ffmpeg-full이 설치되어 있으면 자동으로 찾아 씁니다.)

- Windows: gyan.dev의 "ffmpeg-release-full" 빌드
  (https://www.gyan.dev/ffmpeg/builds/, "full" 표기 빌드에 zscale·libzimg 포함)
  또는 BtbN의 GitHub 릴리스(https://github.com/BtbN/FFmpeg-Builds)의
  "-gpl" 이름이 붙은 빌드를 내려받아 압축을 풀고, 그 안의 ffmpeg.exe 경로를
  PATH에 추가하거나 이 스크립트를 실행할 때 전체 경로로 지정하세요.

- Linux(Debian/Ubuntu 계열): 배포판 기본 `apt-get install ffmpeg`가 보통
  libzimg를 포함하지만 확인이 필요합니다: `ffmpeg -filters | grep zscale`.
  없으면 libzimg를 포함해 직접 빌드하거나, 배포판의 "full" 계열 패키지
  (예: RPM Fusion의 ffmpeg, 또는 johnvansickle.com의 정적 빌드)를 쓰세요.

(위 macOS 경로는 이 컴퓨터에서 실제로 확인했습니다. Windows·Linux 경로는
 일반적으로 알려진 방법이며 이 컴퓨터에서 실측하지 않았습니다.)
EOF
}

# ---------- 2. probe helpers ----------
ffprobe_field() { # $1=file $2=stream-select $3=entry
  ffprobe -v error -select_streams "$2" -show_entries "$3" -of default=noprint_wrappers=1:nokey=1 "$1" 2>/dev/null | head -1
}

is_hdr_source() {
  local f="$1" trc primaries pixfmt
  trc="$(ffprobe_field "$f" v:0 stream=color_transfer)"
  primaries="$(ffprobe_field "$f" v:0 stream=color_primaries)"
  pixfmt="$(ffprobe_field "$f" v:0 stream=pix_fmt)"
  case "$trc" in arib-std-b67|smpte2084) echo yes; return;; esac
  case "$primaries" in bt2020) echo yes; return;; esac
  case "$pixfmt" in *10le|*12le|*p10|*p12) echo yes; return;; esac
  echo no
}

leading_black_seconds() { # $1 = source file; prints trim point in seconds (0 if none)
  local f="$1" line black_start black_end
  # "$FFMPEG" must stay quoted: an ffmpeg path with spaces (e.g. inside
  # "히어로 영상 변환.app", T-125) otherwise fails silently here and the
  # leading black frame is never trimmed.
  line="$("$FFMPEG" -i "$f" -vf "blackdetect=d=0.01:pic_th=0.98:pix_th=0.10" -an -f null - 2>&1 | grep "black_start:0 " | head -1)"
  if [ -n "$line" ]; then
    black_end="$(echo "$line" | sed -n 's/.*black_end:\([0-9.]*\).*/\1/p')"
    echo "${black_end:-0}"
  else
    echo 0
  fi
}

# ---------- 3. build the filter chain ----------
build_vf() { # $1=hdr(yes/no) $2=W $3=H
  local hdr="$1" w="$2" h="$3"
  local scale="scale=w='if(gte(iw/ih,${w}/${h}),-2,${w})':h='if(gte(iw/ih,${w}/${h}),${h},-2)',crop=${w}:${h}"
  if [ "$hdr" = yes ]; then
    echo "zscale=t=linear:npl=${TONEMAP_NPL},format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p,${scale}"
  else
    echo "${scale},format=yuv420p"
  fi
}

# ---------- 4. encode one target ----------
encode_target() { # $1=source $2=profile(pc|mobile) $3=outfile
  local src="$1" profile="$2" out="$3"
  local w h vbitrate maxrate bufsize
  if [ "$profile" = pc ]; then
    w=$PC_W; h=$PC_H; vbitrate=$PC_VBITRATE; maxrate=$PC_MAXRATE; bufsize=$PC_BUFSIZE
  else
    w=$MOBILE_W; h=$MOBILE_H; vbitrate=$MOBILE_VBITRATE; maxrate=$MOBILE_MAXRATE; bufsize=$MOBILE_BUFSIZE
  fi

  local hdr trim vf
  hdr="$(is_hdr_source "$src")"
  trim="$(leading_black_seconds "$src")"
  vf="$(build_vf "$hdr" "$w" "$h")"
  if [ "$trim" != "0" ]; then
    log "  선두 검은 프레임 ${trim}초 감지 -> 영상·소리 함께 자릅니다."
  fi

  # -ss 0 before -i is a harmless no-op, so we always pass it; this avoids
  # bash 3.2's "unbound variable" bug on empty arrays under set -u (macOS's
  # default /bin/bash is 3.2).
  log "  인코딩 중 (HDR 톤매핑: ${hdr}) -> $out"
  "$FFMPEG" -y -ss "$trim" -i "$src" \
    -vf "$vf" \
    -c:v libx264 -profile:v high -level 4.1 -pix_fmt yuv420p \
    -b:v "$vbitrate" -maxrate "$maxrate" -bufsize "$bufsize" \
    -color_primaries bt709 -color_trc bt709 -colorspace bt709 -color_range tv \
    -bsf:v h264_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1:video_full_range_flag=0 \
    -af "alimiter=level=disabled:limit=${LIMITER_LIMIT}:attack=${LIMITER_ATTACK}:release=${LIMITER_RELEASE}" \
    -c:a aac -b:a "$AAC_BITRATE" -ar 48000 -ac 2 \
    -movflags +faststart \
    "$out" >"${out}.encode.log" 2>&1
  local rc=$?
  if [ $rc -ne 0 ]; then
    log "  인코딩 실패 (로그: ${out}.encode.log)"
    return 1
  fi
  rm -f "${out}.encode.log"
  return 0
}

# ---------- 5. console upload-rule check ----------
moov_before_mdat() {
  local f="$1" moov_off mdat_off
  moov_off="$(LC_ALL=C grep -abo "moov" "$f" | head -1 | cut -d: -f1)"
  mdat_off="$(LC_ALL=C grep -abo "mdat" "$f" | head -1 | cut -d: -f1)"
  [ -n "$moov_off" ] && [ -n "$mdat_off" ] && [ "$moov_off" -lt "$mdat_off" ]
}

check_output() { # $1=file $2=profile(pc|mobile) ; prints report, returns 0=ready 1=reject
  local f="$1" profile="$2" reject=0
  local w h warn_bps
  if [ "$profile" = pc ]; then w=$PC_W; h=$PC_H; warn_bps=$PC_WARN_BPS
  else w=$MOBILE_W; h=$MOBILE_H; warn_bps=$MOBILE_WARN_BPS; fi

  echo "----- $(basename "$f") -----"

  if [ ! -f "$f" ]; then echo "거부: 파일이 만들어지지 않았습니다."; return 1; fi

  local codec pixfmt profilev primaries trc awidth aheight duration size acodec
  codec="$(ffprobe_field "$f" v:0 stream=codec_name)"
  pixfmt="$(ffprobe_field "$f" v:0 stream=pix_fmt)"
  profilev="$(ffprobe_field "$f" v:0 stream=profile)"
  primaries="$(ffprobe_field "$f" v:0 stream=color_primaries)"
  trc="$(ffprobe_field "$f" v:0 stream=color_transfer)"
  awidth="$(ffprobe_field "$f" v:0 stream=width)"
  aheight="$(ffprobe_field "$f" v:0 stream=height)"
  duration="$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$f" 2>/dev/null)"
  size="$(stat -f%z "$f" 2>/dev/null || stat -c%s "$f" 2>/dev/null)"
  acodec="$(ffprobe_field "$f" a:0 stream=codec_name)"

  [ "$codec" = "h264" ] || { echo "거부: 영상 코덱이 H.264가 아닙니다 ($codec)."; reject=1; }
  case "$pixfmt" in
    yuv420p) : ;;
    *) echo "거부: 8비트 yuv420p가 아닙니다 ($pixfmt). 프로파일: $profilev"; reject=1 ;;
  esac
  if [ -n "$primaries" ] && [ "$primaries" != "bt709" ] && [ "$primaries" != "unknown" ]; then
    echo "거부: 색 원색이 SDR(BT.709)이 아닙니다 ($primaries)."; reject=1
  fi
  if [ -n "$trc" ] && [ "$trc" != "bt709" ] && [ "$trc" != "unknown" ]; then
    echo "거부: 색 전달특성이 SDR(BT.709)이 아닙니다 ($trc)."; reject=1
  fi
  if moov_before_mdat "$f"; then :; else echo "거부: moov가 파일 앞쪽에 없습니다(faststart 아님)."; reject=1; fi
  if [ -z "$acodec" ]; then
    echo "주의: 소리 트랙이 없습니다. 클릭해 여는 전체 화면 재생에서 소리가 나지 않습니다."
  elif [ "$acodec" != "aac" ]; then
    echo "거부: 소리 코덱이 AAC가 아닙니다 ($acodec)."; reject=1
  fi
  if [ -n "$size" ] && [ "$size" -gt "$MAX_BYTES" ]; then
    echo "거부: 용량이 20 MB를 넘습니다 ($((size / 1024 / 1024)) MB)."; reject=1
  fi
  if [ -n "$duration" ]; then
    local dur_int=${duration%.*}
    if [ "$dur_int" -ge "$MAX_DURATION" ]; then
      echo "거부: 길이가 30초를 넘습니다 (${duration}초)."; reject=1
    fi
    if [ -n "$size" ]; then
      local avg_bps
      avg_bps=$(awk -v s="$size" -v d="$duration" 'BEGIN{ if (d>0) printf "%.0f", (s*8)/d; else print 0 }')
      if [ "$avg_bps" -gt "$warn_bps" ]; then
        echo "주의: 평균 비트레이트가 권장보다 높습니다 (약 $((avg_bps / 1000000)) Mbps)."
      fi
    fi
  fi
  if [ -n "$awidth" ] && [ -n "$aheight" ] && { [ "$awidth" != "$w" ] || [ "$aheight" != "$h" ]; }; then
    echo "주의: 권장 해상도(${w}x${h})와 다릅니다 (${awidth}x${aheight})."
  fi

  local mean_luma
  mean_luma="$("$FFMPEG" -i "$f" -vf "select=eq(n\,0),signalstats" -frames:v 1 -f null - 2>&1 | sed -n 's/.*YAVG:\([0-9.]*\).*/\1/p' | head -1)"
  if [ -n "$mean_luma" ]; then
    local below
    below=$(awk -v m="$mean_luma" 'BEGIN{print (m<16)?1:0}')
    [ "$below" = "1" ] && echo "주의: 첫 장면이 검은 화면에 가깝습니다(평균 밝기 ${mean_luma})."
  fi

  if [ "$reject" -eq 0 ]; then
    echo "판정: 통과 — 콘솔에 올릴 수 있습니다."
  else
    echo "판정: 거부 — 위 사유를 고친 뒤 다시 인코딩하세요."
  fi
  return $reject
}

# ---------- main ----------
SOURCE=""; PC_SRC=""; MOBILE_SRC=""; OUT_DIR=""
while [ $# -gt 0 ]; do
  case "$1" in
    --source) SOURCE="$2"; shift 2;;
    --pc) PC_SRC="$2"; shift 2;;
    --mobile) MOBILE_SRC="$2"; shift 2;;
    --out) OUT_DIR="$2"; shift 2;;
    -h|--help) usage; exit 0;;
    *) die "알 수 없는 인자: $1";;
  esac
done

[ -n "$OUT_DIR" ] || { usage; die "--out OUT_DIR 가 필요합니다."; }
if [ -n "$SOURCE" ]; then
  [ -f "$SOURCE" ] || die "원본 파일을 찾을 수 없습니다: $SOURCE"
  PC_SRC="$SOURCE"; MOBILE_SRC="$SOURCE"
else
  [ -n "$PC_SRC" ] && [ -n "$MOBILE_SRC" ] || { usage; die "--source 하나 또는 --pc/--mobile 둘 다 지정하세요."; }
  [ -f "$PC_SRC" ] || die "PC 원본 파일을 찾을 수 없습니다: $PC_SRC"
  [ -f "$MOBILE_SRC" ] || die "모바일 원본 파일을 찾을 수 없습니다: $MOBILE_SRC"
fi

FFMPEG="$(find_capable_ffmpeg)" || { print_zscale_install_help; exit 1; }
log "사용하는 ffmpeg: $FFMPEG"

mkdir -p "$OUT_DIR"
PC_OUT="$OUT_DIR/landscape-pc-1080p.mp4"
MOBILE_OUT="$OUT_DIR/portrait-mobile-720p.mp4"

log "1/2 PC 파일 만드는 중..."
encode_target "$PC_SRC" pc "$PC_OUT" || exit 1

log "2/2 모바일 파일 만드는 중..."
encode_target "$MOBILE_SRC" mobile "$MOBILE_OUT" || exit 1

echo
echo "=== 콘솔 업로드 규격 확인 ==="
overall=0
check_output "$PC_OUT" pc || overall=1
echo
check_output "$MOBILE_OUT" mobile || overall=1

exit $overall
