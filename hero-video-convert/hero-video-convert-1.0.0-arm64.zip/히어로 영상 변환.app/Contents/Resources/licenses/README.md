# 동봉 소프트웨어 고지 (Third-party notice)

「히어로 영상 변환」 앱은 영상 변환에 아래 소프트웨어를 앱 안에 담아 씁니다
(`Contents/Helpers/ffmpeg`, `Contents/Helpers/ffprobe`).

| 소프트웨어 | 버전 | 라이선스 | 텍스트 |
|---|---|---|---|
| FFmpeg | 9.0.2 | GNU GPL v2 이상 (GPL 구성으로 빌드) | `ffmpeg-COPYING.GPLv2.txt`, `ffmpeg-LICENSE.md` |
| x264 | r3222 | GNU GPL v2 이상 | `x264-COPYING.txt` |
| zimg | 3.0.6 | WTFPL | `zimg-COPYING.txt` |

이 조합(ffmpeg + libx264)의 결과물은 GNU GPL v2 이상을 따릅니다. 각 소프트웨어의
원본 소스 위치, 체크섬, 빌드 설정은 같은 폴더의 `SOURCES.txt`, `ffmpeg-buildconf.txt`,
`configure.log`에 있습니다. 소스는 수정하지 않았고, 빌드 절차는 소스 저장소
`code/tools/hero-video-convert-app/scripts/build-ffmpeg.sh`에 있습니다. 이 앱을 전달받은
분은 위 소스 위치에서 같은 소스를 받을 수 있으며, 요청하면 수행업체가 소스 사본을 제공합니다.

앱의 나머지 부분(SwiftUI 화면, `encode_hero_video.sh`)은 뉴스트럭처 웹 플랫폼 소스
저장소의 일부입니다.
